package ar.org.centro8.curso.java.colegio.test;

import ar.org.centro8.curso.java.colegio.entities.Alumno;

public class TestAlumnos {
    public static void main(String[] args) {
        System.out.println("-- alumno1 --");
        Alumno alumno1=new Alumno(1,"Ana","Cecik",23,1);
        System.out.println(alumno1);
    }
}
