package ar.org.centro8.curso.java.colegio.test;

import ar.org.centro8.curso.java.colegio.entities.Curso;
import ar.org.centro8.curso.java.colegio.enums.Dia;
import ar.org.centro8.curso.java.colegio.enums.Turno;

public class TestCurso {
    public static void main(String[] args) {
        System.out.println("-- curso1 --");
        Curso curso1=new Curso(1,"Java","Rios",Dia.LUNES,Turno.NOCHE);
        System.out.println(curso1);
    }
}
