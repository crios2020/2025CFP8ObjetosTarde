package ar.org.centro8.curso.java.colegio.test;

import java.sql.Connection;
import java.sql.ResultSet;

import ar.org.centro8.curso.java.colegio.connectors.Connector;

public class TestConnector {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select 'Conectado'");
            if(rs.next())       System.out.println(rs.getString(1));
            else                System.out.println("No Conectado");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No Conectado");
        }
    }
}
