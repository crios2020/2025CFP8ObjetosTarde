package ar.org.centro8.curso.java.colegio.test;

import javax.xml.crypto.Data;

import ar.org.centro8.curso.java.colegio.connectors.Connector;
import ar.org.centro8.curso.java.colegio.utils.DataConfig;

public class TestDataConfig {
    public static void main(String[] args) {
        
        //Mapa Properties
        System.out.println(System.getProperties());

        //Recorrido del mapa Properties
        System.out.println("***************************************************");
        System.getProperties().forEach((k,v)->System.out.println(k+" : "+v));
        System.out.println("***************************************************");

        //Sistema Operativo
        System.out.println("-- Sistema Operativo --");
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("os.arch"));

        //Versión de Java
        System.out.println("-- Versión de Java --");
        //System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("java.vm.name"));
        System.out.println(System.getProperty("java.vm.version"));
        System.out.println(System.getProperty("java.version.date"));
        System.out.println(System.getProperty("java.vendor"));

        //UserName
        System.out.println("-- UserName --");
        System.out.println(System.getProperty("user.name"));

        //JDBC
        System.out.println("-- JDBC --");
        System.out.println(Connector.getUrl());

        System.out.println("***************************************************");
        System.out.println(DataConfig.getSO());
        System.out.println(DataConfig.getJava());
        System.out.println(DataConfig.getUserName());
        System.out.println(Connector.getUrl());

    }
}
