package ar.org.centro8.curso.java.colegio.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.colegio.entities.Alumno;
import ar.org.centro8.curso.java.colegio.entities.Curso;
import ar.org.centro8.curso.java.colegio.repositories.AlumnoRepository;
import ar.org.centro8.curso.java.colegio.repositories.CursoRepository;

@Controller
public class AlumnoController {

    private CursoRepository cr=new CursoRepository();
    private AlumnoRepository ar=new AlumnoRepository();
    private String mensaje="Ingrese un nuevo alumno!";

    @GetMapping("alumnos")
    public String getAlumnos(Model model, @RequestParam(name="buscar", defaultValue = "") String buscar){
        Alumno alumno=new Alumno();
        alumno.setEdad(18);
        model.addAttribute("cursos", cr.getAll());
        model.addAttribute("mensaje",mensaje);
        model.addAttribute("alumno",alumno);
        model.addAttribute("alumnos", ar.getLikeApellido(buscar));
        return "alumnos";
    } 

    @PostMapping("guardarAlumno")
    public String guardarAlumno(@ModelAttribute Alumno alumno){
        //System.out.println("***********************************************");
        //System.out.println(alumno);
        //System.out.println("***********************************************");
        ar.save(alumno);
        if(alumno.getId()>0)        mensaje="Se Guardo el alumno id "+alumno.getId();
        else                        mensaje="No se guardo el alumno!";
        return "redirect:alumnos";
    }

}
