package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import ar.org.centro8.curso.java.entities.Auto;

public class TestCollection {
    public static void main(String[] args) {
        
        System.out.println("-- Arrays - Arreglos - Vectores --");
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat", "Idea", "Rojo");
        autos[1]=new Auto("VW", "Gol", "Negro");
        autos[2]=new Auto("Peugeot", "3008", "Blanco");
        autos[3]=new Auto("Renault", "Kangoo", "Verde");

        //Recorrido del vector autos usando indices
        //for(int a=0; a<autos.length; a++){
        //    System.out.println(autos[a]);
        //}

        //Recorrido forEach
        for(Auto auto: autos){
            System.out.println(auto);
        } 

        System.out.println("-- Framework Collection --");

        System.out.println("-- Interface List --");
        List lista;
        lista=new ArrayList();
        //lista=new LinkedList();
        //lista=new Vector();

        lista.add(new Auto("Chevrolet","Corsa","Rojo"));        //0
        lista.add(new Auto("VW","UP","Blanco"));                //1
        lista.add(new Auto("Citroen","C3","Azul"));             //2
        lista.add("Hola");                                                       //
        lista.add(34);                                                           //4
        lista.add("chau mundo");                                                 //5

        lista.add(3,"Lunes");                                       //3
        lista.remove(4);

        //Copiar los autos del vector autos a lista
        for(Auto auto : autos) lista.add(auto);

        System.out.println("*********************************************");
        //Recorrido con indices
        //for(int a=0; a<lista.size(); a++){
        //    System.out.println(lista.get(a));
        //}

        //Recorrido forEach
        //for(Object obj: lista) System.out.println(obj);

        //Método .forEach()         JDK8 o sup
        //lista.forEach(obj->System.out.println(obj));            
        //lista.forEach(obj->{
        //    System.out.println(obj);
        //});   
        lista.forEach(System.out::println);

        //TODO Generics
        //TODO SET


    }
}
