package ar.org.centro8.curso.java.exceptions;

public class NoHayMasPasajesExceptions extends Exception {
    private String nombreVuelo;
    private int cantidadPasajesDisponibles;
    private int cantidadPasajesPedidos;

    public NoHayMasPasajesExceptions(
                                    String nombreVuelo, 
                                    int cantidadPasajesDisponibles, 
                                    int cantidadPasajesPedidos
                                    ) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
        this.cantidadPasajesPedidos = cantidadPasajesPedidos;
    }

    @Override
    public String getMessage() {
        return "El vuelo "+nombreVuelo+", no dispone de "+
            cantidadPasajesPedidos+" pasajes, solo hay disponible "+
            cantidadPasajesDisponibles+" pasajes disponibles.";
    }

    @Override
    public String toString() {
        return getMessage();
    }
   
}

