package ar.org.centro8.curso.java.entities;

public class Auto {
    private String marca;
    private String modelo;
    private String color;
    private static int velocidad;

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + "]";
    }
    //Todo método que use un atributo statico debe ser statico
    public static void acelerar(){
        velocidad+=10;
    }
    public static void frenar(){
        velocidad-=10;
    }
    public static int getVelocidad(){
        return velocidad;
    }

}
