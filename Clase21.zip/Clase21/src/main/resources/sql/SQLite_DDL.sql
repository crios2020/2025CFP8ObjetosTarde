drop table if exists alumnos;
drop table if exists cursos;

create table cursos(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo varchar(25) not null check(length(titulo)>=3),
    profesor varchar(25) not null check (length(profesor)>=3),
    dia TEXT NOT NULL CHECK(dia IN ('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES')),
    turno TEXT NOT NULL CHECK(turno IN ('MAÑANA','TARDE','NOCHE'))
);

create table alumnos(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre varchar(25) not null check(length(nombre)>=3),
    apellido varchar(25) not null check(length(apellido)>=3),
    edad int check(edad>=18 and edad<=130),
    id_curso int not null,
    foreign key (id_curso)
    references cursos(id)
);


