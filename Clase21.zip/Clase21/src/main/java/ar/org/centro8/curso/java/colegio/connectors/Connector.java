package ar.org.centro8.curso.java.colegio.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public final class Connector {

    private static Connection conn=null;

    //MariaDB
    private static String url="jdbc:mariadb://localhost:3306/colegio";
    private static String user="root";
    private static String pass="";

    //SQLite
    //private static String url="jdbc:sqlite:data/colegio.db";
    //private static String user="root";
    //private static String pass="";

    private Connector(){}


    public synchronized static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }

}
