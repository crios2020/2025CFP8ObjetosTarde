/**
 * Clase principal
 * la clase principal debe tener el mismo nombre exacto que el archivo.java
 */
public class Clase01 {
    /**
     * Punto de entrada del proyecto
     * @param args
     */
    public static void main(String[] args) {    //punto de entrada
        
        //linea de comentarios

        /* bloque de comentarios */

        //TODO tarea pendientes

        /**
         * Comentario Java DOC
         * Debe colocarse delante de la declaración de método 
         * o clase.
         * El comentario JavaDoc es visible por fuera del binario
        */

        System.out.println("Hola Mundo");   //imprime en consola
        
        //sout |TAB|
        // F5 para ejecutar

        System.out.println("Hoy es Miércoles!");
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Centro 8");

        /*
         *      Hola Mundo
         *      Hoy es Miércoles!
         *      1234
         *      Centro 8
         *      
         */

        //Uso de Variables

        //Lenguajes Tipado: Java, C#, C++, Visual Basic, Pascal

        //Lenguaje no Tipado: Python, JavaScript, PHP

        //Tipo de datos primitivos

        //Tipo de datos enteros

        //Tipo de datos boolean         1 byte
        boolean bo=true;        //1
        bo=false;               //0
        System.out.println(bo);

        /*
         *      boolean bo=true
         *      00000001
         *      --------
         * 
         */

        //Tipo de datos byte        1 byte  
        byte by=100;
        System.out.println(by);
        by=-100;
        System.out.println(by);

        /*
         * byte by=100;
         * 
         *   |----|----|
         * -128   0    127
         */

        //Tipo de datos short       2 bytes
        short sh=24000;
        System.out.println(sh);

        //Tipo de datos int         4 bytes
        int in=2000000000;
        System.out.println(in);

        //Tipo de datos long        8 bytes
        long lo=3000000000L;
        System.out.println(lo);

        //Tipo de datos char unicode        2 bytes unsigned
        char ch=65;
        System.out.println(ch);
        ch='D';
        System.out.println(ch);
        ch+=32;
        System.out.println(ch);

        //Tipo de datos de Punto Flotante

        //Tipo de datos float           32 bits
        float fl=4.25f;
        System.out.println(fl);

        //Tipo de datos double          64 bits
        double dl=4.25;
        System.out.println(dl);

        fl=10;
        dl=10;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=1000;
        dl=1000;
        System.out.println(fl/3);
        System.out.println(dl/3);

        //Clase BigDecimal

        //Clase String
        String st="Hola";
        System.out.println(st);

        //Tipo de datos var
        var var1=2;                 //int
        var1=40;
        //var1=0.5;                 //error
        var var2=20l;               //long
        var var3=true;              //boolean
        var var4=4.25;              //double
        var var5=4.25d;             //double
        var var6=4.25f;             //float
        var var7='a';               //char
        var var8="a";               //String

        funcion("h");               //String
        funcion('h');               //char
        funcion("true");            //String
        funcion(true);              //boolean
        funcion(2);                 //int
        funcion(2L);                //long
        funcion(5.25);              //double
        funcion(5.25d);             //double
        funcion(5.25f);             //float

        //TODO Métodos String
        //TODO Manipulación de Strings

    }//end main

    public static void funcion(String x){
        System.out.println("String");
    }

    public static void funcion(boolean x){
        System.out.println("boolean");
    }

    public static void funcion(int x){
        System.out.println("int");
    }

    public static void funcion(float x){
        System.out.println("float");
    }

    public static void funcion(double x){
        System.out.println("double");
    }

    public static void funcion(char x){
        System.out.println("char");
    }

    public static void funcion(long x){
        System.out.println("long");
    }

}// end class
