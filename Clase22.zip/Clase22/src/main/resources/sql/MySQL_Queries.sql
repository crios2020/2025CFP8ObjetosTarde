use colegio;

-- 1. Obtener todos los alumnos y sus cursos:
SELECT a.nombre, a.apellido, c.titulo
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id;

-- 2. Contar cuántos alumnos hay por curso:
SELECT c.titulo, COUNT(a.id) AS total_alumnos
FROM cursos c
LEFT JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.id;

-- 3. Listar los cursos que no tienen alumnos:
SELECT c.titulo
FROM cursos c
LEFT JOIN alumnos a ON a.id_curso = c.id
WHERE a.id IS NULL;

-- 4. Obtener los nombres de los alumnos y el día de su curso:
SELECT a.nombre, a.apellido, c.dia
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id;

-- 5. Listar todos los cursos y la edad de los alumnos inscritos:
SELECT c.titulo, a.edad
FROM cursos c
JOIN alumnos a ON a.id_curso = c.id;

-- 6. Obtener la lista de alumnos por turno de curso:
SELECT a.nombre, a.apellido, c.turno
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id
ORDER BY c.turno;

-- 7. Buscar alumnos mayores de 25 años y sus cursos:
SELECT a.nombre, a.apellido, c.titulo
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id
WHERE a.edad > 25;

-- 8. Listar todos los profesores y sus alumnos:
SELECT c.profesor, a.nombre, a.apellido
FROM cursos c
JOIN alumnos a ON a.id_curso = c.id;

-- 9. Contar alumnos por día de curso:
SELECT c.dia, COUNT(a.id) AS total_alumnos
FROM cursos c
LEFT JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.dia;

-- 10. Obtener detalles de los cursos y su profesor, ordenados por profesor:
SELECT c.titulo, c.profesor
FROM cursos c
ORDER BY c.profesor;

-- 11. Listar alumnos y su curso, mostrando solo aquellos que tienen un turno de Noche:
SELECT a.nombre, a.apellido, c.titulo
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id
WHERE c.turno = 'NOCHE';

-- 12. Obtener la lista de cursos y la cantidad de alumnos en cada uno, ordenados por cantidad:
SELECT c.titulo, COUNT(a.id) AS total_alumnos
FROM cursos c
LEFT JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.id
ORDER BY total_alumnos DESC;

-- 13. Buscar todos los alumnos que están en un curso específico:
SELECT a.nombre, a.apellido
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id
WHERE c.titulo = 'Matemáticas';

-- 14. Obtener todos los cursos y la lista de sus alumnos:
SELECT c.titulo, GROUP_CONCAT(a.nombre, ' ', a.apellido) AS alumnos
FROM cursos c
LEFT JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.id;

-- 15. Listar todos los alumnos y su curso, excluyendo los que no tienen curso asignado:
SELECT a.nombre, a.apellido, c.titulo
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id;

-- 16. Obtener el nombre del curso y el número de alumnos por curso:
SELECT c.titulo, COUNT(a.id) AS total_alumnos
FROM cursos c
JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.titulo;

-- 17. Obtener la información de los cursos que tienen más de 5 alumnos:
SELECT c.titulo, COUNT(a.id) AS total_alumnos
FROM cursos c
JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.id
HAVING total_alumnos > 5;

-- 17. Listar todos los alumnos que están en cursos de turno de Mañana:
SELECT a.nombre, a.apellido, c.titulo
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id
WHERE c.turno = 'MAÑANA';

-- 18. Obtener la edad promedio de los alumnos en cada curso:
SELECT c.titulo, AVG(a.edad) AS edad_promedio
FROM cursos c
JOIN alumnos a ON a.id_curso = c.id
GROUP BY c.id;

-- 19. Listar los alumnos y sus cursos, mostrando solo los que están en el curso "Programación":
SELECT a.nombre, a.apellido
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id
WHERE c.titulo = 'Programación';