package ar.org.centro8.curso.java.clase6.test;

import ar.org.centro8.curso.java.clase6.entities.ClientePersona;
import ar.org.centro8.curso.java.clase6.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("-- Test Relaciones --");
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"Arg$");
        cuenta1.depositar(2500000);
        cuenta1.depositar(3200000);
        cuenta1.debitar(1750000);
        System.out.println(cuenta1);

        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2, "Arg$");
        cuenta2.depositar(500000);
        cuenta2.debitar(800000);
        System.out.println(cuenta2);

        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(
                                                            1, 
                                                            "Claudia", 
                                                            40, 
                                                            new Cuenta(3, "Arg$")
                                                        );
        clientePersona1.getCuenta().depositar(1000000);
        System.out.println(clientePersona1);
        clientePersona1.comprar();

        System.out.println("-- clientePersona2 --");
        ClientePersona clientePersona2=new ClientePersona(
                                                            2, 
                                                            "Marcos", 
                                                            40, 
                                                            clientePersona1.getCuenta()    
                                                        );
        clientePersona2.getCuenta().debitar(400000);
        System.out.println(clientePersona2);
        System.out.println(clientePersona1);

        System.out.println("-- clientePersona3 --");
        ClientePersona clientePersona3=new ClientePersona(
                                                            3, 
                                                            "Ana", 
                                                            24, 
                                                            4,
                                                            "Arg$"
                                                        );
        clientePersona3.getCuenta().depositar(350000);
        System.out.println(clientePersona3);


    }
}
