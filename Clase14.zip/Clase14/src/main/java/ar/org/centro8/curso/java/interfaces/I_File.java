package ar.org.centro8.curso.java.interfaces;

public interface I_File {
    
    /*
     * Interfaces
     * - Todos los miembros de una interface son publicos
     * - Una interface no tiene atributos ni constructores
     * - Una interface solo tiene métodos abstractos
     * - Una clase puede implementar muchas interfaces
     */

    void setText(String text);
    String getText();

    //Métodos default JDK8
    default void info(){
        System.out.println("Interface I_File");
    }

}
