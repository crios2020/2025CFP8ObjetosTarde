package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.interfaces.I_File;
import ar.org.centro8.curso.java.utils.FileBinary;
import ar.org.centro8.curso.java.utils.FileText;

public class TestInferfaces {
    public static void main(String[] args) {
        System.out.println("-- Test Interface I_File --");
        I_File file=null;

        //file=new FileText();
        file=new FileBinary();

        //app
        file.setText("texto");
        System.out.println(file.getText());
        file.info();
        
    }
}
