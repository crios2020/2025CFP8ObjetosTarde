package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.List;


import ar.org.centro8.curso.java.entities.Persona;

public class TestApiSTream {
    public static void main(String[] args) {
        List<Persona>personas=new ArrayList();
        personas.add(new Persona("Hernan", "Boti", 45));
        personas.add(new Persona("Laura", "Pérez", 30));
        personas.add(new Persona("Carlos", "Gómez", 28));
        personas.add(new Persona("Ana", "López", 22));
        personas.add(new Persona("Pedro", "Fernández", 35));
        personas.add(new Persona("Sofia", "Martínez", 40));
        personas.add(new Persona("Luis", "García", 50));
        personas.add(new Persona("Maria", "Rodríguez", 33));
        personas.add(new Persona("Javier", "Díaz", 29));
        personas.add(new Persona("Julia", "Castro", 27));
        personas.add(new Persona("Miguel", "Torres", 37));
        personas.add(new Persona("Elena", "Hernández", 31));
        personas.add(new Persona("Ricardo", "Morales", 55));
        personas.add(new Persona("Claudia", "Jiménez", 44));
        personas.add(new Persona("Rafael", "Vega", 39));
        personas.add(new Persona("Teresa", "Soto", 26));
        personas.add(new Persona("Andrés", "Salazar", 48));
        personas.add(new Persona("Carmen", "Cruz", 41));
        personas.add(new Persona("Fernando", "Pacheco", 34));
        personas.add(new Persona("Patricia", "Ríos", 36));
        personas.add(new Persona("Victor", "Núñez", 60));
        personas.add(new Persona("Paola", "Mendoza", 38));
        personas.add(new Persona("Raúl", "Riviera", 43));
        personas.add(new Persona("Inés", "Ceballos", 32));
        personas.add(new Persona("Alfredo", "González", 49));
        personas.add(new Persona("Gloria", "Aguirre", 53));
        personas.add(new Persona("Diego", "Martín", 46));
        personas.add(new Persona("Norma", "Pinto", 52));
        personas.add(new Persona("Santiago", "Valdés", 54));
        personas.add(new Persona("Martha", "Silva", 42));
        personas.add(new Persona("Joaquín", "Ochoa", 24));
        personas.add(new Persona("Nadia", "Bermúdez", 25));
        personas.add(new Persona("Esteban", "Montoya", 57));
        personas.add(new Persona("Luz", "Figueroa", 23));
        personas.add(new Persona("Gabriel", "Quintero", 59));
        personas.add(new Persona("Lucía", "Cortez", 58));
        personas.add(new Persona("Arturo", "Sierra", 61));
        personas.add(new Persona("Fabiola", "Rojas", 62));
        personas.add(new Persona("Samuel", "Vásquez", 63));
        personas.add(new Persona("Diana", "Bautista", 64));
        personas.add(new Persona("Julián", "Pérez", 65));
        personas.add(new Persona("Marcela", "León", 66));
        personas.add(new Persona("Hugo", "Salinas", 67));
        personas.add(new Persona("Verónica", "Cáceres", 68));
        personas.add(new Persona("Cristian", "Cruz", 69));
        personas.add(new Persona("Lorena", "Peña", 70));
        personas.add(new Persona("Fernando", "Alonso", 29));
        personas.add(new Persona("Sara", "Márquez", 34));
        personas.add(new Persona("Eduardo", "Sánchez", 41));
        personas.add(new Persona("Natalia", "Ramos", 38));
        personas.add(new Persona("Alma", "Arrieta", 27));
        personas.add(new Persona("Felipe", "Torres", 45));
        personas.add(new Persona("Carla", "Moreno", 26));
        personas.add(new Persona("Jorge", "Cortés", 50));
        personas.add(new Persona("Silvia", "Pérez", 39));
        personas.add(new Persona("Luis", "Cano", 53));
        personas.add(new Persona("Beatriz", "Guzmán", 46));
        personas.add(new Persona("Pablo", "Salas", 32));
        personas.add(new Persona("Cecilia", "Mena", 48));
        personas.add(new Persona("Rosa", "Campos", 36));
        personas.add(new Persona("Tomás", "Valencia", 33));
        personas.add(new Persona("Clara", "Núñez", 30));
        personas.add(new Persona("Esteban", "Vargas", 40));
        personas.add(new Persona("Mónica", "Soto", 44));
        personas.add(new Persona("Óscar", "Ríos", 59));
        personas.add(new Persona("Verónica", "Ceballos", 62));


        //JAVA Api Stream 

        //select * from personas;
        //personas.forEach(System.out::println);
        personas.stream().forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where nombre='laura';
        //for(Persona persona: personas){
        //    if(persona.getNombre().equalsIgnoreCase("laura"))
        //        System.out.println(persona);
        //}

        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .equalsIgnoreCase("laura"))
                .forEach(System.out::println);

        personas.add(new Persona("Juan", "Pérez", 30));
        System.out.println("*********************************");
        //select * from personas where nombre='juan' and apellido='perez';
        //personas
        //        .stream()
        //        .filter(persona->persona.getNombre().equalsIgnoreCase("juan")
        //                && persona.getApellido().equalsIgnoreCase("pérez"))
        //        .forEach(System.out::println);

        personas
                .stream()
                .filter(persona->persona.getNombre().equalsIgnoreCase("juan"))
                .filter(persona->persona.getApellido().equalsIgnoreCase("pérez"))
                .forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where nombre='juan' or apellido='perez';
        personas
               .stream()
               .filter(persona->persona.getNombre().equalsIgnoreCase("juan")
                       || persona.getApellido().equalsIgnoreCase("pérez"))
               .forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where edad>=30;
        personas
               .stream()
               .filter(persona->persona.getEdad()>=30)
               .forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where edad between 30 and 40;
        //select * from personas where edad>=30 and edad<=40;
        personas
               .stream()
               .filter(persona->persona.getEdad()>=30)
               .filter(persona->persona.getEdad()<=40)
               .forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where nombre like 'm%';
        personas
                .stream()
                .filter(persona->persona.getNombre().toLowerCase().startsWith("m"))
                .forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where nombre like '%a';
        personas
                .stream()
                .filter(persona->persona.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);


        System.out.println("*********************************");
        //select * from personas where nombre like '%ar%';
        personas
                .stream()
                .filter(persona->persona.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);

        System.out.println("*********************************");
        //select * from personas where nombre not like '%ar%';
        personas
                .stream()
                .filter(persona->!persona.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);    
        
        System.out.println("*********************************");
        //select * from personas where edad not between 30 and 40;
        //select * from personas where edad<30 or edad>40;
        personas
               .stream()
               .filter(persona->persona.getEdad()<30 || persona.getEdad()>40)
               .forEach(System.out::println);

    }
}
