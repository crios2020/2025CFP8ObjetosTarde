package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.exceptions.NoHayMasPasajesExceptions;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Vuelo {
    private String nombre;
    private int cantidadPasajesDisponibles;

    public void venderPasajes(int cantidadPasajesPedidos) 
                                    throws NoHayMasPasajesExceptions{
        if(cantidadPasajesPedidos>cantidadPasajesDisponibles)   
            throw new NoHayMasPasajesExceptions(
                                                    nombre, 
                                                    cantidadPasajesDisponibles, 
                                                    cantidadPasajesPedidos
                                                ); 
        cantidadPasajesDisponibles-=cantidadPasajesPedidos;                                                                         
    }

}
