package ar.org.centro8.curso.java.test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

import ar.org.centro8.curso.java.entities.Auto;

public class TestCollection {
    public static void main(String[] args) {
        
        System.out.println("-- Arrays - Arreglos - Vectores --");
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat", "Idea", "Rojo");
        autos[1]=new Auto("VW", "Gol", "Negro");
        autos[2]=new Auto("Peugeot", "3008", "Blanco");
        autos[3]=new Auto("Renault", "Kangoo", "Verde");

        //Recorrido del vector autos usando indices
        //for(int a=0; a<autos.length; a++){
        //    System.out.println(autos[a]);
        //}

        //Recorrido forEach
        for(Auto auto: autos){
            System.out.println(auto);
        } 

        System.out.println("-- Framework Collection --");

        System.out.println("-- Interface List --");
        List lista;
        lista=new ArrayList();
        //lista=new LinkedList();
        //lista=new Vector();

        lista.add(new Auto("Chevrolet","Corsa","Rojo"));        //0
        lista.add(new Auto("VW","UP","Blanco"));                //1
        lista.add(new Auto("Citroen","C3","Azul"));             //2
        lista.add("Hola");                                                       //
        lista.add(34);                                                           //4
        lista.add("chau mundo");                                                 //5

        lista.add(3,"Lunes");                                       //3
        lista.remove(4);

        //Copiar los autos del vector autos a lista
        for(Auto auto : autos) lista.add(auto);

        System.out.println("*********************************************");
        //Recorrido con indices
        //for(int a=0; a<lista.size(); a++){
        //    System.out.println(lista.get(a));
        //}

        //Recorrido forEach
        //for(Object obj: lista) System.out.println(obj);

        //Método .forEach()         JDK8 o sup
        //lista.forEach(obj->System.out.println(obj));            
        //lista.forEach(obj->{
        //    System.out.println(obj);
        //});   
        lista.forEach(System.out::println);

        //Generics <>
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Fiat", "Palio", "Blanco"));
        Auto auto1=lista2.get(0);
        Auto auto2=(Auto)lista.get(0);

        //copiar los elementos del tipo Auto de lista a lista2
        //for(Object obj: lista){
            //if(obj instanceof Auto) lista2.add((Auto)obj);
        //    if(obj.getClass().getSimpleName().equals("Auto")) 
        //        lista2.add((Auto)obj);
        //}
        lista.forEach(obj->{
            if(obj instanceof Auto) lista2.add((Auto)obj);
        });

        System.out.println("******************************");
        //Recorrido de lista1
        lista2.forEach(System.out::println);

        //Interface Set
        Set<String>setNombres=null;
        
        //Implementación HashSet:   Es la más veloz, pero no garantiza el orden de
        //                          los elementos.
        //setNombres=new HashSet();

        //Implementación LinkedHashSet:     Almacena elementos en una lista enlazada,
        //                                  Almacena los elementos por orden de ingreso
        //setNombres=new LinkedHashSet();

        //Impletemación TreeSet():          Almacena elementos en un arbol balanceado
        //                                  Almacena elementos por orden natural
        setNombres=new TreeSet();

        //App Set
        setNombres.add("Juan");
        setNombres.add("Mirta");
        setNombres.add("Ana");
        setNombres.add("Beatriz");
        setNombres.add("Juan");
        setNombres.add("Ana");
        setNombres.add("Maria");
        setNombres.add("Juan");
        setNombres.add("Victor");
        setNombres.add("Jorge");
        setNombres.add("Carlos");
        setNombres.add("Matias");
        setNombres.forEach(System.out::println);

        Set<Auto> setAutos=null;
        //setAutos=new HashSet();
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();

        //app
        setAutos.add(new Auto("Toyota", "Hilux", "Blanca"));
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Chevrolet","Corsa","Rojo"));
        //setAutos.forEach(System.out::println);
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));

        //Pila y Cola
        /*
         * Estructura Pila      LIFO    Last In First Out
         * 
         * Estructura Cola      FIFO    First In First Out
         */
        
        //Clase Stack (Pilas)
        Stack<Auto>pilaAutos=new Stack();
        pilaAutos.push(new Auto("Dodge", "Caravan", "Negro"));
        // método .push()   apila un elemento
        pilaAutos.addAll(lista2);

        System.out.println("************************************************");
        pilaAutos.forEach(System.out::println);

        System.out.println("Longitud pilaAutos: "+pilaAutos.size());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
            // método .pop()        desapila un elemento
        }
        System.out.println("Longitud pilaAutos: "+pilaAutos.size());

        //Clase ArrayDeque (Colas)
        ArrayDeque<Auto> colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("Nissan","March","Rojo"));
        //método .offer()       encolar un elemento
        colaAutos.addAll(lista2);

        System.out.println("************************************************");
        colaAutos.forEach(System.out::println);

        System.out.println("Longitud de colaAutos: "+colaAutos.size());
        while (!colaAutos.isEmpty()) {
            System.out.println(colaAutos.poll());
            //método .poll()            desencola un elemento
        }
        System.out.println("Longitud de colaAutos: "+colaAutos.size());


    }
}
