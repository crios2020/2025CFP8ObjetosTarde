package ar.org.centro8.curso.java.demoThymeleaf.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Index2Controller {
    
    @GetMapping("/index2")
    public String getIndex2(){
        //localhost:8080/index2
        return "index2";
    }
}
