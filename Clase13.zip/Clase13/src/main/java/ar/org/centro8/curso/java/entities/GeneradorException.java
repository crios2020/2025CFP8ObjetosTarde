package ar.org.centro8.curso.java.entities;

public class GeneradorException {
    public static void generar(){
        int[] vector=new int[5];
        vector[10]=20;
    }
    public static void generar(boolean x){
        if(x)   System.out.println(10/0);
    }
    public static void generar(String nro){             // "2x"
        int n=Integer.parseInt(nro);
    }
    public static void generar(String text, int index){         //"hola",2
        //if(text==null || index<0 || index>=text.length()) return;
        System.out.println(text.charAt(index));
    }
}
