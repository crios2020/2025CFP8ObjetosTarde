package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;

public class TestStatic {
    public static void main(String[] args) {
        System.out.println("-- Test Static --");

        Auto.acelerar();                //10

        System.out.println("-- auto1 --");
        Auto auto1=new Auto("Citroen", "C3", "Rojo");
        auto1.acelerar();               //20
        auto1.acelerar();               //30
        System.out.println(auto1+" "+auto1.getVelocidad());

        Auto auto2=new Auto("Fiat","Toro","Bordo");
        auto2.acelerar();               //40
        Auto.acelerar();                //50
        System.out.println(auto2+" "+auto2.getVelocidad());
        System.out.println(auto1+" "+auto1.getVelocidad());


    }
}
