package ar.org.centro8.curso.java.colegio.test;

import ar.org.centro8.curso.java.colegio.entities.Curso;
import ar.org.centro8.curso.java.colegio.enums.Dia;
import ar.org.centro8.curso.java.colegio.enums.Turno;
import ar.org.centro8.curso.java.colegio.repositories.CursoRepository;

public class TestCursoRepository {
    public static void main(String[] args) {
        CursoRepository cr=new CursoRepository();

        Curso curso=new Curso(
                                0,
                                "Javascript",
                                "Gomez",
                                Dia.LUNES,
                                Turno.NOCHE
                            );
        cr.save(curso);
        System.out.println(curso);

        cr.remove(cr.getById(3));

        System.out.println("---------------------------------------------");
        cr.getAll().forEach(System.out::println);

        System.out.println("---------------------------------------------");
        cr.getLikeTitulo("ja").forEach(System.out::println);

        System.out.println("---------------------------------------------");
        cr.getLikeProfesor("ez").forEach(System.out::println);
    
        /*
         * ****************************************************************
         *          El lunes 6/6 no vengo!!!!!!!!!
         * ****************************************************************
         */


    }
}
