package ar.org.centro8.curso.java.colegio.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.curso.java.colegio.connectors.Connector;
import ar.org.centro8.curso.java.colegio.utils.DataConfig;

@Controller
public class ConfiguracionController {

    @GetMapping("configuracion")
    public String getConfiguracion(Model model){
        model.addAttribute("so", DataConfig.getSO());
        model.addAttribute("java", DataConfig.getJava());
        model.addAttribute("username",DataConfig.getUserName());
        model.addAttribute("db", Connector.getUrl());
        return "configuracion";
    }
}
