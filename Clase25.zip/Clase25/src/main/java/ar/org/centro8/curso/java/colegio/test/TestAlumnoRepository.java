package ar.org.centro8.curso.java.colegio.test;

import ar.org.centro8.curso.java.colegio.entities.Alumno;
import ar.org.centro8.curso.java.colegio.repositories.AlumnoRepository;

public class TestAlumnoRepository {
    public static void main(String[] args) {
        AlumnoRepository ar=new AlumnoRepository();

        Alumno alumno=new Alumno(0, "Leandro","Peña",34,1);
        ar.save(alumno);
        System.out.println(alumno);

        ar.remove(ar.getById(51));

        System.out.println("---------------------------------------------------------");
        ar.getAll().forEach(System.out::println);

        System.out.println("---------------------------------------------------------");
        ar.getLikeApellido("ez").forEach(System.out::println);

    }
}
