package ar.org.centro8.curso.java.colegio.controladores;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.colegio.entities.Curso;
import ar.org.centro8.curso.java.colegio.enums.Dia;
import ar.org.centro8.curso.java.colegio.enums.Turno;
import ar.org.centro8.curso.java.colegio.repositories.CursoRepository;

@Controller
public class CursoController {
    
    private String mensaje="Ingrese un nuevo curso";
    private CursoRepository cr=new CursoRepository();

    @GetMapping("cursos")
    public String getCursos(Model model, @RequestParam(name="buscar", defaultValue = "") String buscar){
        Curso curso=new Curso();
        model.addAttribute("dias",List.of(Dia.values()));
        model.addAttribute("turnos",List.of(Turno.values()));
        model.addAttribute("curso",curso);
        model.addAttribute("mensaje", mensaje);
        //model.addAttribute("cursos",cr.getAll());
        model.addAttribute("cursos", cr.getLikeTitulo(buscar));
        return "cursos";
    }

    @PostMapping("guardarCurso")
    public String guardarCurso(@ModelAttribute Curso curso){
        //System.out.println("***********************************************");
        //System.out.println(curso);
        //System.out.println("***********************************************");
        cr.save(curso);
        if(curso.getId()>0)     mensaje="Se Guardo el curso id "+curso.getId();
        else                    mensaje="No se guardo el curso!";
        return "redirect:cursos";
    }

}
