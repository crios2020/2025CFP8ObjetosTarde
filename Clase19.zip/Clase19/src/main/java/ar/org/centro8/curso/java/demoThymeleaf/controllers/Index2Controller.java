package ar.org.centro8.curso.java.demoThymeleaf.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class Index2Controller {
    
    @GetMapping("/index2")
    public String getIndex2(){
        //localhost:8080/index2
        return "index2";
    }

    @GetMapping("/index3")
    public String getIndex3(){
        //localhost:8080/index3
        return "index3";
    }

    @GetMapping("/calculadora")
    public String getCalculadora(){
        //localhost:8080/calculadora
        return "calculadora";
    }

    private int num1=0;
    private int num2=0;
    private String operacion="restar";
    private String resultado="0";

    @GetMapping("/calculadora2")
    public String getCalculadora2(Model model){
        //localhost:8080/calculadora2
        model.addAttribute("num1", num1);
        model.addAttribute("num2", num2);
        model.addAttribute("operacion", operacion);
        model.addAttribute("resultado", resultado);
        return "calculadora2";
    }

    @PostMapping("/calcular")
	public String calcular( @RequestParam("num1") double numero1,
                            @RequestParam("num2") double numero2,
                            @RequestParam("operacion") String op){

        //TODO poner diseño y colores con CSS
    
		//System.out.println("--------------------------------------------------------");
		//System.out.println("hola");
        //System.out.println(numero1);
        //System.out.println(numero2);
        //System.out.println(op);
		//System.out.println("--------------------------------------------------------");
        //resultado="holaaa";
        switch (op) {
            case "sumar":           resultado=(numero1+numero2)+"";                                 break;
            case "restar":          resultado=(numero1-numero2)+"";                                 break;
            case "multiplicar":     resultado=(numero1*numero2)+"";                                 break;
            case "dividir":         resultado=(numero2!=0)?((numero1/numero2)+""):"Error div/0";    break;
        }
		return "redirect:calculadora2";
	}
}
