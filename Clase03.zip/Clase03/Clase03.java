public class Clase03{
    public static void main(String[] args) {
        
        //Manipulación de Strings

        String texto="Esto es una cadena de texto!";
        System.out.println(texto);

        //Recorrido manual de el String texto
        for(int a=0; a<texto.length(); a++){
            System.out.print(texto.charAt(a));
        }
        System.out.println();

        //Recorrido manual en minúsculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            if(car>=65 && car<=90) car+=32;
            System.out.print(car);
        }
        System.out.println();

        //Operador Ternario ?
        //Recorrido manual en minúsculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            System.out.print((car>=65 && car<=90)?car+=32:car);
        }
        System.out.println();

        //Recorrido manual en mayúsculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            System.out.print((car>=97 && car<=122)?car-=32:car);
        }
        System.out.println();


        //Métodos String
        //Métodos toLowerCase() toUpperCase()
        System.out.println(texto.toUpperCase());
        System.out.println(texto.toLowerCase());

        //Método .length()
        System.out.println(texto.length());

        //Método .charAt()
        System.out.println(texto.charAt(3));

        //Método .startsWith() .endsWith()
        System.out.println(texto.startsWith("hola"));   //false
        System.out.println(texto.startsWith("Esto"));   //true
        System.out.println(texto.endsWith("chau"));     //false
        System.out.println(texto.endsWith("!"));        //true

        //Método .contains()
        System.out.println(texto.contains("hola"));          //false
        System.out.println(texto.contains("esto"));          //false
        System.out.println(texto.toLowerCase().contains("esto"));  //true

        //Método .substring()
        System.out.println(texto.substring(10));
        System.out.println(texto.substring(10, 20));

        //Método .trim()
        System.out.println("  hola a todos!!   ".trim());
        //  "hola a todos!!"

        //Método .split()
        String[] palabras=texto.split(" ");
        for(int a=0; a<palabras.length; a++){
            System.out.println(palabras[a]);
        }

        // 1 - Cuantas veces se encuentra la letra 'a' en el
        //     String texto?
        int contA=0;
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            if(car==65 || car==97) contA++;
        }
        System.out.println("Cantidad de A:"+contA);

        //Se puede hacer sin for o while o do while?
        palabras=texto.toLowerCase().split("a");
        System.out.println("Cantidad de A:"+(palabras.length-1));

        // 2 - Cuantas palabras tiene el String texto?
        palabras=texto.split(" ");
        System.out.println("Cantidad de palabras: "+palabras.length);



    }
}