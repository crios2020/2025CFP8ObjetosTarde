import java.text.DecimalFormat;

import javax.swing.JOptionPane;

public class Clase04{
    public static void main(String[] args) {
        //Paradigma de objetos

        /*
         * Para alumnos ausentes
         * https://www.youtube.com/watch?v=UXAltfkVCIw&list=PLMLmotKSEKYfobV2_eyZxVxc88E-27k7t
         * mirar desde video 17 hasta el 31
         * 
         */

        /*
         * Clase: una clase representa una generalización de algo,
         *  se detectan como sustantivos y se identifican con mayúsculas inicial
         *  y en singular.
         * Ejemplo de clases:   Auto, Cliente, Alumno, Profesor
         * 
         * Atributos: Son variables contenidas en una clase y  
         * describen a la clase, 
         * Las clases definen los atributos y los objetos le ponen
         *  estado.
         * Los atributos tienen un tipo de datos definido.
         * 
         * Métodos: Son Acciones que realiza la clase y se las 
         *  encuentra como verbos
         * EJ: saltar() correr() frenar() acelerar()
         * 
         * Objeto:  Un objeto es una instancia en particular de la clase
         * y tiene estado propio.
         * El estado es el valor de sus atributos
         * 
         */


        System.out.println("-- auto1 --");
        Auto auto1=new Auto();      //constructor de Auto
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Rojo";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        auto1.acelerar(26);     //46
        auto1.acelerar(12);     //58
        //imprimimos el estado de auto1
        System.out.println( auto1.marca+" "+auto1.modelo+" "+
                            auto1.color+" "+auto1.velocidad);

        //Las variables deben ser inicializadas.
        //Los atributos tienen una inicialización automática.
        //Los atributos númericos se inicializan en 0.
        //Los atributos String se inicializan en null

        int x;
        //System.out.println(x);  
        //Error la variable debe ser inicializada

        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Idea";
        auto2.color="Rojo";
        
        for(int a=0; a<=60; a++) auto2.acelerar();

        System.out.println( auto2.marca+" "+auto2.modelo+" "+
                            auto2.color+" "+auto2.velocidad);

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Renault","Clio","Rojo");
        auto3.acelerar();
        auto3.imprimirVelocidad();
        System.out.println(auto3.obtenerVelocidad());
        //JOptionPane.showMessageDialog(null,
        //    "Velocidad: "+auto3.obtenerVelocidad());

        System.out.println(auto3.getEstado());
        System.out.println(auto3.toString());
        System.out.println(auto3);


        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(
                                        1,
                                        "Ana",
                                        "Rosi",
                                        "Gerente",
                                        4000000
                                        );
        //empleado1.sueldoBasico=5000000;
        empleado1.setSueldoBasico(5000000);
        System.out.println(empleado1);
    
        DecimalFormat df=new DecimalFormat("0.00");

        System.out.println("-- rectangulo1 --");
        Rectangulo rectangulo1=new Rectangulo(20, 20);
        System.out.println("Perímetro: "+df.format(rectangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(rectangulo1.getSuperficie()));

        System.out.println("-- triangulo1 --");
        Triangulo triangulo1=new Triangulo(20,20);
        System.out.println("Perímetro: "+df.format(triangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(triangulo1.getSuperficie()));

        System.out.println("-- circulo1 --");
        Circulo circulo1=new Circulo(30);
        System.out.println("Perímetro: "+df.format(circulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(circulo1.getSuperficie()));

    }
}