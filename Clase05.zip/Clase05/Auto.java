//Declaración de clases
public class Auto {
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Métodos constructores

    /**
     * Método deprecado por Carlos Rios el 20/08/2025,
     * por ser inseguro
     * Usar en su reemplazo 
     * Auto(String marca, String modelo, String color)
     */
    @Deprecated
    Auto(){}    //Constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //Métodos
    void acelerar(){
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);
    }

    //Método con párametro de entrada
    //Método con sobrecarga de método

    /**
     * @param kilometros Cantidad de kilometros a acelerar
     */
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;        //regla de negocio
    }

    void frenar(){
        velocidad-=10;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    //método con devolución de parámetros
    int obtenerVelocidad(){
        return velocidad;
    }

    public String getEstado(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }

    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }

}//end class Auto
