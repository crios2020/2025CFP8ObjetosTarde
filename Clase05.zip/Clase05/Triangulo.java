public class Triangulo {
    double base;
    double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }
    
    double getPerimetro(){
        return base+altura+Math.hypot(base, altura);
    }

    double getSuperficie(){
        return base*altura;
    }

}
