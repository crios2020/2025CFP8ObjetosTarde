package ar.org.centro8.curso.java.clase6.entities;

public class ClientePersona {
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;

    /*
     * Un cliente puede crearse sin una cuenta.
    */
    //public ClientePersona(int nro, String nombre, int edad){
    //    this.nro=nro;
    //    this.nombre=nombre;
    //    this.edad=edad;
    //} 

    /*
     * Un cliente siempre tiene una cuenta.
     * Una cuenta puede pertenecer a más de una persona.
     */
    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
        this.cuenta=cuenta;
    }

    /*
     * Un cliente siempre tiene una cuenta.
     * Una cuenta solo pertenece a un cliente
     */
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta, String moneda){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
        this.cuenta=new Cuenta(nroCuenta, moneda);
    }

    @Override
    public String toString() {
        return "ClientePersona [nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + "]";
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void comprar(){
        System.out.println("Compra realizada!!");
    }
    
}
