package ar.org.centro8.curso.java.clase6.entities;

public abstract class Persona {
    private String nombre;
    private int edad;
    private Direccion direccion;

    public Persona(String nombre, int edad, Direccion direccion) {
        this.nombre = nombre;
        this.edad = edad;
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Persona [nombre=" + nombre + ", edad=" + edad + ", direccion=" + direccion + "]";
    }

    //public void saludar(){
    //    System.out.println("Hola soy una persona!");
    //}

    public abstract void saludar();

}
