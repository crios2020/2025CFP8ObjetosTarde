package ar.org.centro8.curso.java.clase6.test;

import ar.org.centro8.curso.java.clase6.entities.Cliente;
import ar.org.centro8.curso.java.clase6.entities.Cuenta;
import ar.org.centro8.curso.java.clase6.entities.Direccion;
import ar.org.centro8.curso.java.clase6.entities.Persona;
import ar.org.centro8.curso.java.clase6.entities.Vendedor;

public class TestDiagramaHerencia {
    public static void main(String[] args) {
        System.out.println("-- Test Diagrama Herencia --");

        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Medrano",162,"1","1");
        System.out.println(dir1);

        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion(
                                        "Lima", 
                                        222, 
                                        null, 
                                        null, 
                                        "Moron"
                                    );
        System.out.println(dir2);

        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Ana",40,dir1);
        System.out.println(persona1);
        persona1.saludar();
        */

        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(
                                            1, 
                                            "Sanuel", 
                                            40, 
                                            dir2, 
                                            2400000
                                        );
        System.out.println(vendedor1);
        vendedor1.saludar();

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(
                                        "Ana",
                                        32,
                                        dir1,
                                        1,
                                        new Cuenta(
                                                    1, 
                                                    "args")
                                    );
        System.out.println(cliente1);
        cliente1.saludar();

    }
}
