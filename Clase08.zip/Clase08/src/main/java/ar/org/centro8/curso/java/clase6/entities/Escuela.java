package ar.org.centro8.curso.java.clase6.entities;

import java.util.ArrayList;
import java.util.List;

public class Escuela {
    private String nombre;
    private List<Estudiante>estudiantes;

    public Escuela(String nombre) {
        this.nombre = nombre;
        this.estudiantes = new ArrayList();
    }

    @Override
    public String toString() {
        return "Escuela [nombre=" + nombre + ", estudiantes=" + estudiantes + "]";
    }

    public void agregarEstudiante(Estudiante estudiante){
        this.estudiantes.add(estudiante);
    }

    public void listarEstudiantes(){
        System.out.println(estudiantes);
    }
    
}
