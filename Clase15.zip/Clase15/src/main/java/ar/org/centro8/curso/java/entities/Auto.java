package ar.org.centro8.curso.java.entities;

public class Auto implements Comparable<Auto>{
    private String marca;
    private String modelo;
    private String color;
    private static int velocidad;

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + "]";
    }
    
    @Override
    public int compareTo(Auto para) {
        String thisAuto=this.getMarca()+","+this.getModelo()+","+this.getColor();
        String paraAuto=para.getMarca()+","+para.getModelo()+","+para.getColor();
        return thisAuto.compareTo(paraAuto);
    }

    @Override
    public int hashCode() {
        return toString().hashCode();
    }
    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        return this.hashCode()==obj.hashCode();
    }

    //Todo método que use un atributo statico debe ser statico
    public static void acelerar(){
        velocidad+=10;
    }
    public static void frenar(){
        velocidad-=10;
    }
    public static int getVelocidad(){
        return velocidad;
    }
    public String getMarca() {
        return marca;
    }
    public String getModelo() {
        return modelo;
    }
    public String getColor() {
        return color;
    }

}
