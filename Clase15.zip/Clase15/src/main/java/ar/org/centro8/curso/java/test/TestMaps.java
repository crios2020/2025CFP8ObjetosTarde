package ar.org.centro8.curso.java.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Empleado;

public class TestMaps {
    public static void main(String[] args) {
        Map<String,String>mapaSemana=null;

        //Implementación HashMap:   Es la implementación más veloz.
        //                          No Garantiza el orden de los elementos
        //mapaSemana=new HashMap();

        //Implementación Hashtable: Es legacy (obsoleta) fue reemplazada por HashMap
        //mapaSemana=new Hashtable();

        //Implementación LinkedHashMap: Almacena elementos en una lista enlazada por
        //                              orden de ingreso
        //mapaSemana= new LinkedHashMap();

        //Implementación TreenMap:      Almacena elementos en un arbol balanceado
        //                              por orden natural.
        mapaSemana=new TreeMap();

        //app
        mapaSemana.put("lu", "Lunes");
        mapaSemana.put("ma", "Martes");
        mapaSemana.put("mi", "Miércoles");
        mapaSemana.put("ju", "Jueves");
        mapaSemana.put("vi", "Viernes");
        mapaSemana.put("sa", "Sábado");
        mapaSemana.put("do", "Domingo");
        System.out.println(mapaSemana.get("ma"));
        mapaSemana.forEach((k,v)->System.out.println(k+" - "+v));

        Empleado empleado1=new Empleado(
                                            1, 
                                            "Mercedes", 
                                            "Morales", 
                                            850000
                                        );
        Empleado empleado2=new Empleado(
                                            2, 
                                            "Debora", 
                                            "Vargas", 
                                            6540000
                                        );
        Empleado empleado3=new Empleado(
                                            3, 
                                            "Melina", 
                                            "Miguel", 
                                            5460000
                                        );
        
        Map<Empleado, Auto>mapaEmpleadosAutos=new LinkedHashMap();
        mapaEmpleadosAutos.put(empleado1, new Auto("VW","Bora","Rojo"));
        mapaEmpleadosAutos.put(empleado2, new Auto("Citroen","C4","Azul"));
        mapaEmpleadosAutos.put(empleado3, new Auto("Toyota","Etios","Blanco"));
        System.out.println(mapaEmpleadosAutos.get(empleado2));
        



    }
}
