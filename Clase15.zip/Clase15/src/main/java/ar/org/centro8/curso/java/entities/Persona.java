package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Persona implements Comparable<Persona>{
    private String nombre;
    private String apellido;
    private int edad;

    @Override
    public int compareTo(Persona para) {
        DecimalFormat df=new DecimalFormat("000");
        String thisPersona=this.getApellido()+","+this.getNombre()+","+df.format(this.getEdad());
        String paraPersona=para.getApellido()+","+para.getNombre()+","+df.format(para.getEdad());
        return thisPersona.compareTo(paraPersona);
    }

}
