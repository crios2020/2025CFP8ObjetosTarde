package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Empleado;

public class TestLombox {
    public static void main(String[] args) {
        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(
                                        1,
                                        "Ana",
                                        "Gomez",
                                        8888888
                            );
        empleado1.setSueldoBasico(1200000);
        System.out.println(empleado1);


    }  
}
