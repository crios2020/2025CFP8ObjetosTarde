package ar.org.centro8.curso.java.test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import ar.org.centro8.curso.java.entities.GeneradorException;

public class TestException {
    public static void main(String[] args) {
        //System.out.println(10/0);
        //System.out.println("-- Esta linea no se ejecuta --");

        /*
                //Estructura Try - Catch - Finally
                try{                                //Obligatorio
                    //Colocar todas las sentencias que puedan arrojar una Exception.
                    //Estas sentencias tienen más costo de hardware.
                    //Si se puede ejecutar sin errores el bloque termina normalmente.
                    //Si hay una exception (error) el bloque corta la ejecución.
                    // y se ejecuta el bloque catch.
                }catch(Exception e){                //Obligatorio
                    //Este bloque solo se ejectua si ocurrio una exception en try.
                    //Se recibe como parámetro un objeto de Exception.
                }finally{                           //Opcional
                    //Este bloque se ejecuta siempre.
                    //Las variables declaradas en try o catch estan fuera de alcance.
                }
                //El programa termina normalmente.
         */

        try {
            System.out.println(10/0);
            System.out.println("- Esta linea no se ejecuta -");
        } catch (Exception e) {
            System.out.println("Ocurrio un error");
            System.out.println(e);
        } finally {
            System.out.println("El programa termina normalmente");
        }

        try {
            //GeneradorException.generar();
            //GeneradorException.generar(true);
            //GeneradorException.generar("22x");
            //GeneradorException.generar(null,2);
            //GeneradorException.generar("hola",-1);
            //GeneradorException.generar("hola",20);
            //FileReader in=new FileReader("texto.txt");
        } catch (Exception e) {
            System.out.println(e);
        }

        //uncheckedException
        //GeneradorException.generar("hola",20);

        //checkedException
        //FileReader in=new FileReader("texto.txt");

        //Captura personalizada de exception
        try {
            //GeneradorException.generar();
            //GeneradorException.generar(true);
            //GeneradorException.generar("22x")
            //GeneradorException.generar(null,2);
            //GeneradorException.generar("hola",20);
            FileReader in=new FileReader("texto.txt");
        //} catch (ArrayIndexOutOfBoundsException e)  
        //                {System.out.println("Indice Fuera de Rango!");
        } catch (ArithmeticException e)             
                        {System.out.println("División / 0!");
        } catch (NullPointerException e)            
                        {System.out.println("Puntero Nulo!");
        //} catch (StringIndexOutOfBoundsException e) 
        //                {System.out.println("Indice fuera de Rango!");
        //}catch(ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e)
        //                {System.out.println("Indice fuera de Rango!");
        } catch (IndexOutOfBoundsException e)
                        {System.out.println("Indice fuera de Rango!");
        } catch (NumberFormatException e)           
                        {System.out.println("Formato de número incorrecto!");
        } catch (FileNotFoundException e)           
                      {System.out.println("Archivo no encontrado");
        } catch (IOException e)                     
                      {System.out.println("Error IO!");
        } catch (Exception e)                       
                        {System.out.println("Ocurrio un error no esperado!");
        }


        //TODO Exception para validar reglas de negocio
        //TODO interfaces
        //TODO static

    }
}
