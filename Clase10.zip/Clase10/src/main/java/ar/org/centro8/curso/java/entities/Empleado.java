package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//@Getter                                 //métodos Getters
//@Setter                                 //métodos Setters
//@ToString                               //método toString
@Data                                 //toString - Getters - Setters - Equals&hashcode
@AllArgsConstructor                     //Constructor parámetrico total
//@NoArgsConstructor                      //Constructor vacio
public class Empleado {
    private int nroLegajo;
    private String nombre;
    private String apellido;
    private double sueldoBasico;
}
