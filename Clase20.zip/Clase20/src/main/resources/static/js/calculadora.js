function sumar(){
    let nro1=parseFloat(document.getElementById("num1").value)
    let nro2=parseFloat(document.getElementById("num2").value)
    resultado=nro1+nro2
    document.getElementById("resultado").value=resultado
}

function restar(){
    let nro1=parseFloat(document.getElementById("num1").value)
    let nro2=parseFloat(document.getElementById("num2").value)
    resultado=nro1-nro2
    document.getElementById("resultado").value=resultado
}

function multiplicar(){
    let nro1=parseFloat(document.getElementById("num1").value)
    let nro2=parseFloat(document.getElementById("num2").value)
    resultado=nro1*nro2
    document.getElementById("resultado").value=resultado
}

function dividir(){
    let nro1=parseFloat(document.getElementById("num1").value)
    let nro2=parseFloat(document.getElementById("num2").value)
    if(nro2!=0)     resultado=nro1+nro2
    else            resultado="Error div/0"
    document.getElementById("resultado").value=resultado
}