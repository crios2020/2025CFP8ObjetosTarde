function sumar(){
    let nro1=document.getElementById("num1")
    let nro2=document.getElementById("num2")
    
}