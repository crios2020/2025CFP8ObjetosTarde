package ar.org.centro8.curso.java.demoThymeleaf.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Index2Controller {
    
    @GetMapping("/index2")
    public String getIndex2(){
        //localhost:8080/index2
        return "index2";
    }

    @GetMapping("/index3")
    public String getIndex3(){
        //localhost:8080/index3
        return "index3";
    }

    @GetMapping("/calculadora")
    public String getCalculadora(){
        //localhost:8080/calculadora
        return "calculadora";
    }
}
