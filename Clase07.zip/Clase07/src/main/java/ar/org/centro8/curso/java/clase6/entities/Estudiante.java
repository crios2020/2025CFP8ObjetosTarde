package ar.org.centro8.curso.java.clase6.entities;

public class Estudiante {
    private String nombre;
    private int edad;
    
    public Estudiante(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Estudiante [nombre=" + nombre + ", edad=" + edad + "]";
    }

    
}
