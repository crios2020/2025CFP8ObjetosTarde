package ar.org.centro8.curso.java.clase6.test;

import ar.org.centro8.curso.java.clase6.entities.Escuela;
import ar.org.centro8.curso.java.clase6.entities.Estudiante;

public class TestLaboratorio {
    public static void main(String[] args) {
        System.out.println("-- Test Laboratorio --");
        System.out.println("-- estudiante1 --");
        Estudiante estudiante1=new Estudiante("Javier", 24);
        System.out.println(estudiante1);

        System.out.println("-- escuela1 --");
        Escuela escuela1=new Escuela("Belgrano");
        escuela1.agregarEstudiante(estudiante1);
        escuela1.agregarEstudiante(new Estudiante("Melina", 18));
        escuela1.agregarEstudiante(new Estudiante("Paula", 18));
        escuela1.agregarEstudiante(new Estudiante("Karina", 18));
        escuela1.agregarEstudiante(new Estudiante("Amanda", 18));

        System.out.println(escuela1);
        escuela1.listarEstudiantes();
    }
}
