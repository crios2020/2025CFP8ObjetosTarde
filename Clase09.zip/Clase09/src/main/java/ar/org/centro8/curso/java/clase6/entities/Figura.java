package ar.org.centro8.curso.java.clase6.entities;

public abstract class Figura {
    public abstract double getPerimetro();
    public abstract double getSuperficie();
    public abstract String getEstado();
}
