package ar.org.centro8.curso.java.clase6.entities;
public class Circulo extends Figura{
    private double radio;
    public Circulo(double radio) {
        this.radio = radio;
    }
    @Override
    public String toString() {
        return "Circulo [radio=" + radio + "]";
    }
    @Override
    public String getEstado() {
        return toString();
    }
    @Override
    public double getPerimetro() {
        return Math.PI*2*radio;
    }
    @Override
    public double getSuperficie() {
        return Math.PI*radio*radio;
    }
}
