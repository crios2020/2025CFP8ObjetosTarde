package ar.org.centro8.curso.java.clase6.test;

import java.text.DecimalFormat;

import ar.org.centro8.curso.java.clase6.entities.Circulo;
import ar.org.centro8.curso.java.clase6.entities.Rectangulo;
import ar.org.centro8.curso.java.clase6.entities.Triangulo;

public class TestFigura {
    public static void main(String[] args) {
        DecimalFormat df=new DecimalFormat("0.00");

        System.out.println("-- Test Figuras --");
        System.out.println("-- rectangulo1 --");
        Rectangulo rectangulo1=new Rectangulo(20, 30);
        System.out.println(rectangulo1.getEstado());
        System.out.println("Perímetro: "+df.format(rectangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(rectangulo1.getSuperficie()));

        System.out.println("-- triangulo1 --");
        Triangulo triangulo1=new Triangulo(20, 30);
        System.out.println(triangulo1.getEstado());
        System.out.println("Perímetro: "+df.format(triangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(triangulo1.getSuperficie()));

        System.out.println("-- circulo1 --");
        Circulo circulo1=new Circulo(50);
        System.out.println(circulo1.getEstado());
        System.out.println("Perímetro: "+df.format(circulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(circulo1.getSuperficie()));

    }  
}
