package ar.org.centro8.curso.java.clase6.test;

import ar.org.centro8.curso.java.clase6.entities.Cliente;
import ar.org.centro8.curso.java.clase6.entities.Cuenta;
import ar.org.centro8.curso.java.clase6.entities.Direccion;
import ar.org.centro8.curso.java.clase6.entities.Persona;
import ar.org.centro8.curso.java.clase6.entities.Vendedor;

public class TestObject {
    public static void main(String[] args) {
        
        Cliente cliente1=new Cliente(
                                    "Ana",
                                    34,
                                    new Direccion("Lima",222,null,null),
                                    1,
                                    new Cuenta(1, "Arg$")
                            );
        Vendedor vendedor1=new Vendedor(
                                    1, 
                                    "Raul", 
                                    30, 
                                    new Direccion("Viel", 30, null, null),
                                    850000);
        
        //Polimorfismo - Poliformismo
        Persona p1=cliente1;
        Persona p2=vendedor1;

        p1.saludar();
        p2.saludar();

        System.out.println(p1.getClass());
        System.out.println(p1.getClass().getName());
        System.out.println(p1.getClass().getSimpleName());
        System.out.println(p1.getClass().getSuperclass().getName());
        System.out.println(p1.getClass().getSuperclass().getSuperclass().getName());
        System.out.println(p1.getClass().getSuperclass().getSuperclass().getSuperclass());
        System.out.println("".getClass().getName());
        System.out.println("".getClass().getSuperclass().getName());

        Object obj;
        obj="hola";
        obj=2;
        obj=p1;

        System.out.println(obj);

        //Operador Casting
        Cliente cliente=(Cliente)obj;

        //Clase interna (Inner Class)
        class Dato{
            int dato;
            Dato(int dato){
                this.dato=dato;
            }
        }

        Dato d1=new Dato(2);
        Dato d2=d1;
        Dato d3=new Dato(d1.dato);

        //hashCode()
        System.out.println("d1.hashCode(): "+d1.hashCode());
        System.out.println("d2.hashCode(): "+d2.hashCode());
        System.out.println("d3.hashCode(): "+d3.hashCode());

        //equals
        System.out.println("d1.equals(d1): "+d1.equals(d1));        //true
        System.out.println("d1.equals(d2): "+d1.equals(d2));        //true
        System.out.println("d1.equals(d3): "+d1.equals(d3));        //false



    }
}
