package ar.org.centro8.curso.java.clase6.entities;

public class Vendedor extends Persona{
    private int nroLegajo;
    private double sueldoBasico;

    public Vendedor(
                        int nroLegajo, 
                        String nombre, 
                        int edad, 
                        Direccion direccion, 
                        double sueldoBasico
    ){
        super(nombre, edad, direccion);         //llama al cosntructor de la clase Padre
        this.nroLegajo=nroLegajo;
        this.sueldoBasico=sueldoBasico;
    }

    @Override
    public String toString() {
        return "Vendedor [nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + "]"
                +super.toString();          
    }

    @Override
    public void saludar(){
        System.out.println("Hola soy un vendedor!!");
    }

}
