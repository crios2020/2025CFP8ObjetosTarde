select version();
drop database if exists colegio;
create database colegio;
drop table if exists alumnos;
drop table if exists cursos;

create table cursos(
    id int auto_increment primary key,
    titulo varchar(25) not null check(length(titulo)>=3),
    profesor varchar(25) not null check (length(profesor)>=3),
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    turno enum('MAÑANA','TARDE','NOCHE')
);

create table alumnos(
    id int auto_increment primary key,
    nombre varchar(25) not null check(length(nombre)>=3),
    apellido varchar(25) not null check(length(apellido)>=3),
    edad int check(edad>=18 and edad<=130),
    id_curso int not null
);

-- TODO Foreing Key constraint
